const DEFAULTS = { enabled: true, color: "#1b1f2a", image: "", blur: 0, dim: 0.25, sidebars: false };
const $ = (id) => document.getElementById(id);
let state = { ...DEFAULTS };

function save() {
  chrome.storage.local.set({ settings: state });
  render();
}

function render() {
  $("enabled").checked = state.enabled;
  $("color").value = state.color;
  $("blur").value = state.blur;
  $("blurVal").textContent = state.blur;
  $("dim").value = Math.round(state.dim * 100);
  $("dimVal").textContent = Math.round(state.dim * 100);
  $("sidebars").checked = state.sidebars;
  $("url").value = state.image.startsWith("data:") ? "" : state.image;
  const p = $("preview");
  p.style.backgroundColor = state.color;
  p.style.backgroundImage = state.image ? `url("${state.image}")` : "none";
}

function resizeToDataUrl(file, maxSize = 1920) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objUrl = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(objUrl);
      resolve(c.toDataURL("image/jpeg", 0.9));
    };
    img.onerror = reject;
    img.src = objUrl;
  });
}

$("enabled").onchange = (e) => { state.enabled = e.target.checked; save(); };
$("color").oninput = (e) => { state.color = e.target.value; save(); };
$("blur").oninput = (e) => { state.blur = +e.target.value; save(); };
$("dim").oninput = (e) => { state.dim = +e.target.value / 100; save(); };
$("sidebars").onchange = (e) => { state.sidebars = e.target.checked; save(); };
$("url").onchange = (e) => { state.image = e.target.value.trim(); save(); };
$("file").onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  state.image = await resizeToDataUrl(f);
  save();
};
$("clear").onclick = () => { state.image = ""; save(); };
$("reset").onclick = () => { state = { ...DEFAULTS }; save(); };

chrome.storage.local.get("settings").then((r) => {
  state = { ...DEFAULTS, ...(r.settings || {}) };
  render();
});
