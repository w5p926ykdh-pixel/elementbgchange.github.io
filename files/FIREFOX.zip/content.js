(() => {
  const LAYER_ID = "ebg-layer";
  const STYLE_ID = "ebg-style";
  const DEFAULTS = { enabled: true, color: "#1b1f2a", image: "", blur: 0, dim: 0.25, sidebars: false };

  function apply(saved) {
    const s = Object.assign({}, DEFAULTS, saved || {});
    const root = document.documentElement;
    let layer = document.getElementById(LAYER_ID);
    let style = document.getElementById(STYLE_ID);

    if (!s.enabled) {
      if (layer) layer.remove();
      if (style) style.remove();
      return;
    }
    if (!layer) {
      layer = document.createElement("div");
      layer.id = LAYER_ID;
      root.appendChild(layer);
    }
    if (!style) {
      style = document.createElement("style");
      style.id = STYLE_ID;
      root.appendChild(style);
    }

    const dim = `linear-gradient(rgba(0,0,0,${s.dim}),rgba(0,0,0,${s.dim}))`;
    const img = s.image ? `${dim}, url("${s.image.replace(/"/g, "%22")}")` : "none";
    layer.style.cssText = [
      "position:fixed", "inset:0", "z-index:-1", "pointer-events:none",
      `background-color:${s.color}`,
      `background-image:${img}`,
      "background-size:cover", "background-position:center", "background-repeat:no-repeat",
      `filter:blur(${s.blur}px)`,
      s.blur > 0 ? "transform:scale(1.05)" : "transform:none",
    ].join(";");

    const chat = [
      "#matrixchat", ".mx_MatrixChat_wrapper", ".mx_MatrixChat", ".mx_MainSplit",
      ".mx_RoomView", ".mx_RoomView_wrapper", ".mx_RoomView_container", ".mx_RoomView_body",
      ".mx_RoomView_timeline", ".mx_RoomView_messagePanel", ".mx_RoomView_MessageList",
      ".mx_ScrollPanel", ".mx_AutoHideScrollbar", ".mx_HomePage", ".mx_RoomView_auxPanel",
      ".mx_RoomView_statusArea", ".mx_RoomView_statusAreaBox", ".mx_AuxPanel",
      ".mx_RoomView_messageListWrapper", ".mx_RoomView_MessageList > li",
    ];
    const sidebars = [
      ".mx_LeftPanel", ".mx_LeftPanel_wrapper", ".mx_LeftPanel_outerWrapper", ".mx_SpacePanel",
      ".mx_RightPanel", ".mx_RoomHeader", ".mx_RoomListPanel", ".mx_RoomList",
      ".mx_RoomSublist", ".mx_LeftPanel_roomListContainer", ".mx_ThreadPanel",
    ];
    const targets = s.sidebars ? chat.concat(sidebars) : chat;

    // Element/Compound paint most panels through CSS variables, so override
    // those too, but only inside the app (dialogs and menus stay opaque).
    const vars = [
      "--cpd-color-bg-canvas-default", "--cpd-color-bg-canvas-default-level-1",
      "--timeline-background-color", "--background", "--primary-content-bg",
    ];
    const sideVars = ["--cpd-color-bg-subtle-secondary", "--cpd-color-bg-subtle-primary",
      "--roomlist-background-color", "--sidebar-bg-color"];
    const varList = (s.sidebars ? vars.concat(sideVars) : vars)
      .map((v) => `${v}: transparent !important;`).join(" ");

    style.textContent =
      "html, body { background: transparent !important; }\n" +
      "#matrixchat, .mx_MatrixChat_wrapper, .mx_MatrixChat { " + varList + " }\n" +
      targets.join(",\n") + " { background: transparent !important; " + varList + " }";
  }

  const api = typeof browser !== "undefined" ? browser : chrome;
  api.storage.local.get("settings").then((r) => apply(r.settings));
  api.storage.onChanged.addListener((changes) => {
    if (changes.settings) apply(changes.settings.newValue);
  });
})();
